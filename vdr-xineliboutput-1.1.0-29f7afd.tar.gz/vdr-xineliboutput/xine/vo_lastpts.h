/*
 * vo_lastpts.h:
 *
 * See the main source file 'xineliboutput.c' for copyright information and
 * how to reach the author.
 *
 * $Id$
 *
 */

#ifndef _XINELIBOUTPUT_VO_LASTPTS_H
#define _XINELIBOUTPUT_VO_LASTPTS_H

vo_driver_t *vo_lastpts_init(void);

#endif /* _XINELIBOUTPUT_VO_LASTPTS_H */
