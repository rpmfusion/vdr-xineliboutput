#ifndef _GNOME_SCREENSAVER_H
#define _GNOME_SCREENSAVER_H

extern void gnome_screensaver_control(int enable);

#endif /* !_GNOME_SCREENSAVER_H */
