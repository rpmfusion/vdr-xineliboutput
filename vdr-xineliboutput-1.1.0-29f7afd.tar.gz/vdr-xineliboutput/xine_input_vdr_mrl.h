/*
 * xine_input_vdr_mrl.h:  
 *
 * See the main source file 'xineliboutput.c' for copyright information and
 * how to reach the author.
 *
 * $Id$
 *
 */

#ifndef XINE_INPUT_VDR_MRL_H
#define XINE_INPUT_VDR_MRL_H

# ifndef MRL_ID

#  define MRL_ID      "xvdr"

#  undef  MRL_ID_LEN
#  define MRL_ID_LEN  4

# endif

#endif
